#!/bin/sh
set -ex

# Move to application directory
cd /app

# Ensure storage directories exist
mkdir -p /app/storage/fileuploads /app/storage/objectstore

# Run any new database migrations
python manage.py migrate --no-input

# Load test fixture data only on initial run
if [ ! -f storage/firstrun ]; then
    python manage.py seeddata
    touch storage/firstrun
fi

# Create Admin User, ignore errors if it already exists
python manage.py createsuperuser --noinput || true

# Create/update service accounts from env vars
python manage.py create_service_accounts

# Start gunicorn with native ASGI workers — required for WebSocket support via Channels
exec opentelemetry-instrument gunicorn mysite.asgi:application --worker-class asgi --bind 0.0.0.0:8000 --workers 4
