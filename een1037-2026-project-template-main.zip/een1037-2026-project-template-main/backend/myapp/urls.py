from django.urls import path

from . import views

app_name='myapp'
urlpatterns = [
    path('', views.index, name='index'),
    path('message/add/', views.add_example_message, name='add_example_message'),
    path('profile/', views.profile_edit, name='profile_edit'),
    path('profile/<str:username>', views.profile_detail, name='profile_detail'),
    path('register/', views.user_registration, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('media/example_images/<int:message_id>', views.serve_example_image, name='serve_example_image'),
]
