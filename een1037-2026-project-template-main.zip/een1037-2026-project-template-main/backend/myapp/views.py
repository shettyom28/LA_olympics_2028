import logging

from django.http import FileResponse, Http404, HttpRequest
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.shortcuts import render, get_object_or_404, redirect

logger = logging.getLogger(__name__)

from .consumers import broadcast_notification
from .models import ExampleMessage, UserProfile
from .forms import ExampleMessageForm, RegistrationForm, LoginForm, EditUserProfileForm
from .service_pub import publish_example_message


def index(request: HttpRequest):
    board_messages = ExampleMessage.objects.all().order_by('-created_at')
    form = ExampleMessageForm()
    context = {
        'board_messages': board_messages,
        'form': form,
    }
    return render(request, 'myapp/index.html', context)


@login_required
def add_example_message(request: HttpRequest):
    if request.method == 'POST':
        form = ExampleMessageForm(request.POST)
        if not form.is_valid():
            logger.error('Invalid message from %s: %s', request.user.username, form.errors)
            board_messages = ExampleMessage.objects.all().order_by('-created_at')
            context = {
                'board_messages': board_messages,
                'form': form,
            }
            return render(request, 'myapp/index.html', context)
        logger.info('Creating message from %s', request.user.username)
        message = ExampleMessage.objects.create(
            user=request.user,
            content=form.cleaned_data['content'],
        )
        publish_example_message(message_id=message.id, text=message.content, username=request.user.username)
        broadcast_notification(f"New message from {request.user.username}")
    return redirect('myapp:index')


def user_registration(request: HttpRequest):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password']
            )
            profile = UserProfile.objects.create(
                user=user,
                interests=form.cleaned_data['interests'])
            return redirect('myapp:login')
    else:
        form = RegistrationForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/register.html', context)


def user_login(request: HttpRequest):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            logger.info('Login attempt for %s', username)
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('myapp:index')
            else:
                form.add_error(None, 'Invalid username or password.')
    else:
        form = LoginForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/login.html', context)


@login_required
def user_logout(request: HttpRequest):
    logout(request)
    return redirect('myapp:index')


@login_required
def profile_edit(request: HttpRequest):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    if request.method == 'POST':
        form = EditUserProfileForm(request.POST)
        if form.is_valid():
            user_profile.interests = form.cleaned_data['interests']
            user_profile.save()
            return redirect('myapp:profile_edit')
    else:
        initial = {
            'interests': user_profile.interests,
        }
        form = EditUserProfileForm(initial=initial)
    context = {
        'form': form,
    }
    return render(request, 'myapp/profile_edit.html', context)


def profile_detail(request: HttpRequest, username: str):
    target_user = get_object_or_404(User, username=username)
    context = {
        'target_user': target_user,
    }
    return render(request, 'myapp/profile_detail.html', context)


def serve_example_image(request: HttpRequest, message_id: int):
    """Serve the image attached to an ExampleMessage."""
    message = get_object_or_404(ExampleMessage, id=message_id)
    if not message.image:
        raise Http404
    storage = message.image.storage
    return FileResponse(storage.open(message.image.name, 'rb'))
