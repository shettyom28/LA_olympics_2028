from django.contrib.auth.models import User
from rest_framework import serializers

from .models import ExampleMessage, UserProfile


class RegisterSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    email = serializers.EmailField(required=False, default='')
    password = serializers.CharField(write_only=True)

    def validate_username(self, value: str):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError('Username already taken.')
        return value

    def create(self, validated_data: dict):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
        )
        UserProfile.objects.create(user=user)
        return user


class AuthUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username']
        read_only_fields = ['id', 'username']


class ExampleMessageSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    image = serializers.SerializerMethodField()

    class Meta:
        model = ExampleMessage
        fields = ['id', 'user', 'username', 'content', 'image', 'random_number', 'created_at']
        read_only_fields = ['user', 'random_number', 'created_at']

    def get_image(self, obj: ExampleMessage) -> str | None:
        if obj.image:
            from django.urls import reverse
            return reverse('myapp:serve_example_image', args=[obj.id])
        return None


class ExampleResultSerializer(serializers.Serializer):
    random_number = serializers.IntegerField()


class UserProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    date_joined = serializers.DateTimeField(source='user.date_joined', read_only=True)

    class Meta:
        model = UserProfile
        fields = ['username', 'date_joined', 'interests']
