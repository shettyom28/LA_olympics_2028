from pathlib import Path

from django.core.files.base import ContentFile
from django.core.files.storage import storages
from django.core.management import call_command
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Load example seed data into the database and file storages."

    def handle(self, *args, **options):
        call_command("loaddata", "seeddata")
        self._load_storage_files("default")
        self._load_storage_files("objectstore")

    def _load_storage_files(self, storage_name: str):
        # Load file using Django Storage API (FileSystemStorage, S3Storage, etc)
        storage = storages[storage_name]
        source_dir = Path(__file__).resolve().parent.parent.parent / "fixtures" / "storages" / storage_name
        count = 0
        for file_path in source_dir.rglob("*"):
            if not file_path.is_file() or file_path.name == '.gitkeep':
                continue
            relative = file_path.relative_to(source_dir)
            storage_path = relative.as_posix()
            if storage.exists(storage_path):
                storage.delete(storage_path)
            storage.save(storage_path, ContentFile(file_path.read_bytes()))
            count += 1
        self.stdout.write(f"Loaded {count} files into storage '{storage_name}'.")
