from django.core.files.storage import storages
from django.db import models
from django.contrib.auth.models import User


def get_object_store():
    return storages["objectstore"]


class ExampleMessage(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    image = models.FileField(upload_to='example_images/', blank=True, null=True)
    random_number = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username}: {self.content[:50]}'


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    interests = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.user.username
