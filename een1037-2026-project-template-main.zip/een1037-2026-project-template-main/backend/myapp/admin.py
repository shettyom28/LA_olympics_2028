from django.contrib import admin
from .models import ExampleMessage, UserProfile


@admin.register(ExampleMessage)
class ExampleMessageAdmin(admin.ModelAdmin):
    list_display = ['user', 'content', 'random_number', 'created_at']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user__username']
