from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient

from myapp.models import ExampleMessage


class ExampleMessageAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.alice = User.objects.create_user(username="alice", password="pass123")

    def test_message_list(self):
        ExampleMessage.objects.create(user=self.alice, content="Hello world")
        response = self.client.get("/api/v1/example-messages/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["content"], "Hello world")

    def test_message_create_requires_auth(self):
        response = self.client.post(
            "/api/v1/example-messages/", {"content": "Anonymous message"}
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_message_create_authenticated(self):
        self.client.force_authenticate(user=self.alice)
        response = self.client.post(
            "/api/v1/example-messages/", {"content": "Hello from Alice"}
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["username"], "alice")
        self.assertEqual(response.data["content"], "Hello from Alice")
