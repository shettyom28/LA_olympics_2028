from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

from . import api_views

app_name = 'api'
urlpatterns = [
    path('schema/', SpectacularAPIView.as_view(), name='schema'),
    path('docs/', SpectacularSwaggerView.as_view(url_name='api:schema'), name='docs'),

    path('auth/', include('dj_rest_auth.urls')),
    path('auth/register/', api_views.RegisterView.as_view(), name='register'),

    path('example-messages/', api_views.ExampleMessageListView.as_view(), name='example-message-list'),
    path('example-messages/<int:message_id>/result/', api_views.ExampleResultView.as_view(), name='example-message-result'),

    path('profiles/<str:username>/', api_views.UserProfileView.as_view(), name='user-profile'),
]
