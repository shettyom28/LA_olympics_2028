from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from myapp.models import ExampleMessage, UserProfile


class ViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="bob", password="pass123")
        UserProfile.objects.create(user=self.user)

    def test_index_loads(self):
        response = self.client.get(reverse("myapp:index"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Message Board")

    def test_logged_in_user_can_post_message(self):
        self.client.login(username="bob", password="pass123")
        response = self.client.post(reverse("myapp:add_example_message"), {
            "content": "Hello world!",
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(ExampleMessage.objects.filter(content="Hello world!").exists())

    def test_anonymous_cannot_post_message(self):
        response = self.client.post(reverse("myapp:add_example_message"), {
            "content": "Anonymous message",
        })
        # Should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertFalse(ExampleMessage.objects.exists())

    def test_registration_creates_user_and_profile(self):
        self.client.post(reverse("myapp:register"), {
            "username": "newbie",
            "email": "n@example.com",
            "password": "secret123",
            "confirm_password": "secret123",
            "interests": "Django",
        })
        self.assertTrue(User.objects.filter(username="newbie").exists())
        self.assertTrue(UserProfile.objects.filter(user__username="newbie").exists())
