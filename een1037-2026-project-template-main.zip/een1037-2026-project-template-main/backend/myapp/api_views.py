from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from drf_spectacular.utils import extend_schema
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

from .consumers import broadcast_notification
from .models import ExampleMessage, UserProfile
from .permissions import IsServiceAccount
from .service_pub import publish_example_message
from .serializers import (
    AuthUserSerializer,
    ExampleMessageSerializer,
    ExampleResultSerializer,
    UserProfileSerializer,
    RegisterSerializer,
)


class ExampleMessageListView(APIView):
    """List all messages or create a new one (login required)."""
    serializer_class = ExampleMessageSerializer

    def get(self, request: Request):
        messages = ExampleMessage.objects.select_related('user').order_by('-created_at')
        serializer = ExampleMessageSerializer(messages, many=True)
        return Response(serializer.data)

    def post(self, request: Request):
        if not request.user.is_authenticated:
            return Response(status=status.HTTP_403_FORBIDDEN)
        serializer = ExampleMessageSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        message = serializer.save(user=request.user)
        publish_example_message(
            message_id=message.id,
            text=message.content,
            username=request.user.username,
        )
        broadcast_notification(f"New message from {request.user.username}")
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class ExampleResultView(APIView):
    """Submit a result for a message. (Internal System API)"""
    serializer_class = ExampleResultSerializer
    permission_classes = [IsServiceAccount]

    @extend_schema(responses={200: ExampleMessageSerializer})
    def post(self, request: Request, message_id: int):
        message = get_object_or_404(ExampleMessage, id=message_id)
        serializer = ExampleResultSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        message.random_number = serializer.validated_data['random_number']
        message.save(update_fields=['random_number'])
        return Response(ExampleMessageSerializer(message).data)


class UserProfileView(APIView):
    """Retrieve or update a user profile."""
    serializer_class = UserProfileSerializer

    def get(self, request: Request, username: str):
        user = get_object_or_404(User, username=username)
        profile, _ = UserProfile.objects.get_or_create(user=user)
        return Response(UserProfileSerializer(profile).data)

    def put(self, request: Request, username: str):
        if not request.user.is_authenticated:
            return Response(status=status.HTTP_403_FORBIDDEN)
        if request.user.username != username:
            return Response(status=status.HTTP_403_FORBIDDEN)
        profile, _ = UserProfile.objects.get_or_create(user=request.user)
        serializer = UserProfileSerializer(profile, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class RegisterView(APIView):
    """Register a new user account."""
    serializer_class = RegisterSerializer

    @extend_schema(responses={201: AuthUserSerializer})
    def post(self, request: Request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(AuthUserSerializer(user).data, status=status.HTTP_201_CREATED)
