# My App

## Development

### Requirements

* Python 3.10+
* Visual Studio Code
  * Extension: "Python" (ms-python.python)

### Instructions

To run the project:

* Open in Visual Studio code
* F1 -> "Python: Create Environment" -> "Venv" -> ... "requirements.txt"
* F1 -> "Python: Select Interpreter" -> ".venv"
* "Run and Debug"
  * `manage.py makemigrations`
  * `manage.py migrate`
  * `manage.py createsuperuser`
  * `manage.py seeddata`
  * `manage.py runserver`
  * `manage.py runserver (debug logs)`
* Open <http://localhost:8000> in the web browser.


### Example accounts:

* testadmin: testpass
* testuser: testpass


### Creating a staff account

* Open <http://localhost:8000/admin> in the web browser.
* Login with these credentials:
  * Username: admin
  * Password: admin
* Create a new "User" object
  * Enable "Staff status"
* Create a new "User Profile" object
  * Set "User" to be the user you just made
* Logout
* Open <http://localhost:8000/login>
* Login with the staff user's credentials


## Source Template

This project was created from:

```
django-admin startproject mysite .
django-admin startapp myapp
```