import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/useAuth'

function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  async function handleLogout() {
    await logout()
    navigate('/')
  }

  return (
    <nav>
      <Link to="/"><strong>My App</strong></Link> <small>React</small>
      {' | '}
      {user ? (
        <>
          <Link to={`/profile/${user.username}`}>
            Logged in as <strong>{user.username}</strong>
          </Link>
          {' | '}
          <button onClick={handleLogout}>Logout</button>
        </>
      ) : (
        <>
          <Link to="/login">Login</Link>
          {' | '}
          <Link to="/register">Register</Link>
        </>
      )}
      <hr />
    </nav>
  )
}

export default Navbar
