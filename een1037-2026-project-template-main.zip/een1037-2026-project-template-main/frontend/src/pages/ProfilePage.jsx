import { useState, useEffect } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'
import api from '../api/client'
import { useAuth } from '../context/useAuth'

function ProfilePage() {
  const { username } = useParams()
  const { user } = useAuth()
  const queryClient = useQueryClient()

  const { data: profile, error, isLoading } = useQuery({
    queryKey: ['profiles', username],
    queryFn: () => api.get(`/api/v1/profiles/${username}/`),
  })

  const [interests, setInterests] = useState('')
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState('')

  const isOwnProfile = user && user.username === username

  useEffect(() => {
    if (profile) {
      setInterests(profile.interests || '')
    }
  }, [profile])

  async function handleSaveInterests(e) {
    e.preventDefault()
    setSaving(true)
    setSaveError('')
    try {
      await api.put(`/api/v1/profiles/${username}/`, { interests })
      queryClient.invalidateQueries({ queryKey: ['profiles', username] })
    } catch (err) {
      setSaveError(err.message)
    } finally {
      setSaving(false)
    }
  }

  if (isLoading) return <p>Loading...</p>
  if (error) return <p>Error: {error.message}</p>
  if (!profile) return <p>User not found.</p>

  return (
    <div>
      <h2>{profile.username}</h2>
      <p>Member since {new Date(profile.date_joined).toLocaleDateString()}</p>

      {isOwnProfile ? (
        <form onSubmit={handleSaveInterests}>
          {saveError && <p style={{ color: 'red' }}>{saveError}</p>}
          <div>
            <label htmlFor="interests">Interests</label><br />
            <textarea id="interests" rows="3" value={interests} onChange={(e) => setInterests(e.target.value)} />
          </div>
          <button type="submit" disabled={saving}>
            {saving ? 'Saving...' : 'Save Interests'}
          </button>
        </form>
      ) : profile.interests ? (
        <div>
          <strong>Interests:</strong>
          <p>{profile.interests}</p>
        </div>
      ) : null}
    </div>
  )
}

export default ProfilePage
