// API client — Axios instance with JWT bearer tokens
// For production packages, use 

import axios from 'axios'
import { traceparent } from './traceparent'


// JWT sessionStorage functions

const JWT_TOKEN_KEY = 'auth_tokens'

function getJwtTokens() {
  return JSON.parse(sessionStorage.getItem(JWT_TOKEN_KEY))
}

export function saveJwtTokens(access, refresh) {
  sessionStorage.setItem(JWT_TOKEN_KEY, JSON.stringify({ access, refresh }))
}

export function clearJwtTokens() {
  sessionStorage.removeItem(JWT_TOKEN_KEY)
}

export function hasJwtTokens() {
  return sessionStorage.getItem(JWT_TOKEN_KEY) !== null
}


// Axios API client instance with JWT bearer tokens

const api = axios.create()

api.interceptors.request.use((config) => {
  const tokens = getJwtTokens()
  if (tokens?.access) {
    config.headers.Authorization = `Bearer ${tokens.access}`
  }
  config.headers.traceparent = traceparent()
  return config
})

api.interceptors.response.use(
  (response) => response.data,
  async (error) => {
    const original = error.config

    // On 401, attempt one JWT token refresh then retry
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      const tokens = getJwtTokens()
      if (tokens?.refresh) {
        try {
          const { data } = await axios.post('/api/v1/auth/token/refresh/', {
            refresh: tokens.refresh,
          })
          saveJwtTokens(data.access, data.refresh || tokens.refresh)
          return api(original)
        } catch {
          clearJwtTokens()
        }
      }
    }

    // Build error from common error fieldnames in response body
    const data = error.response?.data
    const err = new Error(data?.detail || data?.error || error.message)
    err.status = error.response?.status
    err.data = data
    throw err
  }
)

export default api
