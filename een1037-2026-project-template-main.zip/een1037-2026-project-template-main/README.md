# EEN1037 Project Template

See [DEVELOPMENT.md](DEVELOPMENT.md) for instructions on starting this stack with docker-compose, and how to develop inside Visual Studio Code.